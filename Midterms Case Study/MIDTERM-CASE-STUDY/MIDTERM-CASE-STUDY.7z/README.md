# MIDTERM-CASE-STUDY

 Instructor: Engr. Dylan Josh D. Lopez <br>

 Submitted by: Surio, Rovil Jr., M

 November 28, 2020
